from django.shortcuts import render,redirect
from orders.models import Order,OrderItem

# Create your views here.

def dashboard(request):
    if request.user.is_authenticated:
        user=request.user
        email=user.email
        orders=Order.objects.filter(email=email)
        if orders:

            person = orders[0]
            detailsdict={'first_name':user.first_name,'last_name':user.last_name,'email':user.email,'phone':person.phone,'address':person.address,'postal_code':person.postal_code}
            ordersdict=[]
            for order in orders:
                date=order.created
                items=order.items.all()

                new=[]
                for item in items:
                    product= item.product
                    price=item.price
                    quan= item.quantity
                    price = price * quan
                    d={'product':product,'price':price,'quan':quan,'date':date}
                    new.append(d)
                ordersdict.append(new)

            context={'details':detailsdict,'orders':ordersdict}
            return render(request,'order.html',context)
        else:
            details={'first_name':user.first_name,'last_name':user.last_name,'email':user.email}
            context={'details':details}
            return render(request, 'order.html',context)
    else:
        return redirect('home')
