from django.shortcuts import render
from django.http import HttpResponse
from django.template.loader import render_to_string
from ecommerce.settings import EMAIL_HOST_USER
from django.core.mail import send_mail


import razorpay
client = razorpay.Client(auth=("rzp_test_P2W9Z3QEsVnq86", "JHsfJwImArkNI6ZhoseuP4sD"))


def create_order(request,order):
    global x
    x = order
    total = int(order.get_total_cost())
    if total < 799:
        total += 50

    context = {}
    order_currency = 'INR'
    order_receipt = 'order_rcptid_11'
    notes = {}

    # CREATING ORDER
    response = client.order.create(dict(amount=total, currency=order_currency, receipt=order_receipt, notes=notes, payment_capture='0'))
    order_id = response['id']
    order_status = response['status']

    if order_status=='created':

        # Server data for user convinience
        context['product_id'] = x.id
        context['price'] = total
        context['name'] = str(x.first_name) + str( x.last_name)
        context['phone'] = x.phone
        context['email'] = x.email

        # data that'll be send to the razorpay for
        context['order_id'] = order_id

        return render(request, 'payments/confirm_order.html', context)


        # print('\n\n\nresponse: ',response, type(response))
    return HttpResponse('<h1>Error in  create order function</h1>')



def payment_status(request):

    response = request.POST

    params_dict = {
        'razorpay_payment_id' : response['razorpay_payment_id'],
        'razorpay_order_id' : response['razorpay_order_id'],
        'razorpay_signature' : response['razorpay_signature']
    }


    # VERIFYING SIGNATURE
    try:
        status = client.utility.verify_payment_signature(params_dict)
        print("DONE")
        ordersdict = []
        items = x.items.all()
        total = x.get_total_cost()
        if total < 799:
            total += 50
        cust_dict = {'name': x.first_name, 'phone': x.phone, 'address': x.address, 'postal_code': x.postal_code,
                     'city': x.city, 'date': x.created, 'state': x.state}

        for item in items:
            product = item.product
            price = item.price
            quan = item.quantity
            price = price * quan
            d = {'product': product, 'price': price, 'quan': quan}
            ordersdict.append(d)

        subject = "Your Order Has Been Placed"
        plain_message = "HELLO"
        context = {'orders': ordersdict, 'total': total, 'customer': cust_dict}
        message = render_to_string('mail.html', context)
        message.content_subtype = "html"
        recipients = [x.email,"electrohost2050@gmail.com"]

        send_mail(subject, plain_message, EMAIL_HOST_USER, recipients, html_message=message)

        return render(request, 'confirmation.html', {'status': 'Payment Successful','id':x.id})
    except:
        return render(request, 'payments/order_summary.html', {'status': 'Payment Faliure!!!'})

