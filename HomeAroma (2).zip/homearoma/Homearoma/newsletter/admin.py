from django.contrib import admin
from .models import Email,News

# Register your models here.

admin.site.register(Email)
admin.site.register(News)

