from django.shortcuts import render
from .models import Contact
from django.contrib import messages

# Create your views here.

def contact(request):

    if request.method == "POST":
        name     = request.POST['name']
        email    = request.POST['email']
        subject  = request.POST['subject']
        message  = request.POST['message']
        data = Contact(name=name,email=email,subject=subject,message=message)
        data.save()
        messages.info(request, 'Mail man is on Way, Will Reach Soon')


        return render(request,'contact.html')



    else:
        return render(request,'contact.html')

def about(request):

    return render(request,'about.html')