from django.apps import AppConfig


class StickersConfig(AppConfig):
    name = 'stickers'
