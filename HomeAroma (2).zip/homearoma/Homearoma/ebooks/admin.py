from django.contrib import admin
from .models import Ebooks
# Register your models here.

admin.site.register(Ebooks)
