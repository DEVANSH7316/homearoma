from django.shortcuts import render
from .models import Ebooks
# Create your views here.


def ebook(request):


    ebooks   = Ebooks.objects.all()
    
    return render(request,'ebooks.html',{'ebooks':ebooks})
    

