"""electrocom URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path,include
from . import views
from blog.models import Blog
from stickers import urls
from ebooks import urls
from newsletter import urls

urlpatterns = [

    path('', views.index ,name="home"),
    path('', include('social_django.urls', namespace='social')),
    path('',include('ebooks.urls')),
    path('',include('stickers.urls')),
    path('blog/',views.blog,name='blogs'),    
    path('blog/<str:name>',views.blog_detail,name='name'),
    path('',include("newsletter.urls"))
  
]
