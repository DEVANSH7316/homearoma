from django.db import models
from tinymce.models import HTMLField

# Create your models here.

Trend_CHOICES = (
   ('Y', 'Yes'),
   ('N', 'No')
)

class Ebooks(models.Model):
    title      =     models.CharField(max_length =60)
    author     =     models.CharField(max_length=20) 
    url        =     models.TextField()
    image      =     models.ImageField(upload_to= 'images/ebooks',default='')
    description=     HTMLField()
    trends     =     models.CharField(choices=Trend_CHOICES, max_length=128)


    def __str__(self):
            return self.title

    