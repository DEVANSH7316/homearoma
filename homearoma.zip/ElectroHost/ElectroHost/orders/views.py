from django.shortcuts import render,redirect
from .models import OrderItem
from .forms import OrderCreateForm
from cart.cart import Cart
from payments.views import create_order
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User



def order_create(request):
    cart = Cart(request)
    if request.user.is_authenticated:

        if request.method == 'POST':
            form = OrderCreateForm(request.POST)
            if form.is_valid():
                order = form.save()
                for item in cart:
                    OrderItem.objects.create(
                        order=order,
                        product=item['product'],
                        price=item['price'],
                        quantity=item['quantity']
                    )
                cart.clear()

            # return render(request, 'payments/pay.html', {'total': order})
            return create_order(request,order)

        else:
            form = OrderCreateForm()
            delivery=0
            total=cart.get_total_price()
            if cart.get_total_price() < 799:
                delivery=50
                total+=delivery

        return render(request, 'checkout.html', {'form': form,'delivery':delivery , 'total':total})
    else:
       return redirect('login')