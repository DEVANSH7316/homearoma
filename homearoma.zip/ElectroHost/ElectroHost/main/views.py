from django.shortcuts import render
from blog.models  import Blog
from shop.models import Category, Product
from ebooks.models import Ebooks
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

# # from products.models import Products
#
# # Create your views here.
def index(request):
    
    blog   = Blog.objects.filter(trends = 'Y')
    ebooks = Ebooks.objects.filter(trends = 'Y')
    context = {'blog':blog,
                'ebooks':ebooks,}

        
    return render(request,'index.html',context)

    # return render(request,'index.html')



def blog(request):

    context   = Blog.objects.all()
    paginator = Paginator(context,4)
    page = request.GET.get('page')
    try:
        context = paginator.page(page)
    except PageNotAnInteger:
            # If page is not an integer deliver the first page
        context = paginator.page(1)
    except EmptyPage:
        # If page is out of range deliver last page of results
        context = paginator.page(paginator.num_pages)
    return render(request,'blog.html',{'context':context})

def blog_detail(request,name):
    context = Blog.objects.filter(name=name)

    return render(request,'blog-single.html',{'page': page,'context':context})
