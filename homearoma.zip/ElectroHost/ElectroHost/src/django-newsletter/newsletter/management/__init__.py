# -*- coding: utf-8 -*-
# management commands for the newsletter
